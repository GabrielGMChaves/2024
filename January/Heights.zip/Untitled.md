```python
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
```


```python
df = pd.read_csv("C:/Users/bielz/OneDrive/Documentos/GitHub/2024/January/annual-change-in-average-male-height.csv")
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Entity</th>
      <th>Code</th>
      <th>Year</th>
      <th>Mean male height (cm)</th>
      <th>Mean female height (cm)</th>
      <th>Year-on-year change in female height (%)</th>
      <th>Year-on-year change in male height (%)</th>
      <th>Population (historical estimates)</th>
      <th>Daily caloric intake per person that comes from animal protein</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>1896.0</td>
      <td>161.164095</td>
      <td>149.187747</td>
      <td>0.08962</td>
      <td>0.01997</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>1897.0</td>
      <td>161.196286</td>
      <td>149.321451</td>
      <td>0.08977</td>
      <td>0.01986</td>
      <td>10694804.0</td>
      <td>55.128870</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>1898.0</td>
      <td>161.228297</td>
      <td>149.455494</td>
      <td>0.08966</td>
      <td>0.02011</td>
      <td>10745168.0</td>
      <td>54.959705</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>1899.0</td>
      <td>161.260727</td>
      <td>149.589503</td>
      <td>0.08963</td>
      <td>0.02005</td>
      <td>12057436.0</td>
      <td>57.932200</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>1900.0</td>
      <td>161.293068</td>
      <td>149.723587</td>
      <td>0.08949</td>
      <td>0.02010</td>
      <td>14003764.0</td>
      <td>58.493233</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>59618</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1010281.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>59619</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1020609.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>59620</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1031042.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>59621</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1041582.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>59622</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1052230.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>59623 rows × 9 columns</p>
</div>




```python
import matplotlib.pyplot as plt
import seaborn as sns

# Visualize distribution of male and female heights
plt.figure(figsize=(10, 6))
sns.histplot(data['Mean male height (cm)'], bins=30, kde=True, color='blue', label='Male Height')
sns.histplot(data['Mean female height (cm)'], bins=30, kde=True, color='pink', label='Female Height')
plt.title('Distribution of Male and Female Heights')
plt.xlabel('Height (cm)')
plt.ylabel('Frequency')
plt.legend()
plt.show()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[4], line 6
          4 # Visualize distribution of male and female heights
          5 plt.figure(figsize=(10, 6))
    ----> 6 sns.histplot(data['Mean male height (cm)'], bins=30, kde=True, color='blue', label='Male Height')
          7 sns.histplot(data['Mean female height (cm)'], bins=30, kde=True, color='pink', label='Female Height')
          8 plt.title('Distribution of Male and Female Heights')
    

    NameError: name 'data' is not defined



    <Figure size 1000x600 with 0 Axes>



```python
data=df
```


```python
plt.figure(figsize=(10, 6))
sns.histplot(data['Mean male height (cm)'], bins=30, kde=True, color='blue', label='Male Height')
sns.histplot(data['Mean female height (cm)'], bins=30, kde=True, color='pink', label='Female Height')
plt.title('Distribution of Male and Female Heights')
plt.xlabel('Height (cm)')
plt.ylabel('Frequency')
plt.legend()
plt.show()

```


    
![png](output_5_0.png)
    



```python
plt.figure(figsize=(10,6))
sns.histplot(data['Mean male height (cm)'], bins=20, kde=True, color='blue', label='Male Height')
sns.histplot(data['Mean female height (cm)'], bins=20, kde=True, color='red', label='Female Height')
plt.title('Distribution of Male and Female Heights')
plt.xlabel('Height (cm)')
plt.ylabel('Frequency')
plt.legend()
plt.show()
```


    
![png](output_6_0.png)
    



```python
plt.plot(df['Year'],df['Mean male height (cm)'])
```




    [<matplotlib.lines.Line2D at 0x1ad629539d0>]




    
![png](output_7_1.png)
    



```python
plt.figure(figsize=(12, 6))
sns.lineplot(x='Year', y='Mean male height (cm)', data=data, label='Male Height', color='blue')
sns.lineplot(x='Year', y='Mean female height (cm)', data=data, label='Female Height', color='pink')
plt.title('Trends in Male and Female Height Over the Years')
plt.xlabel('Year')
plt.ylabel('Mean Height (cm)')
plt.legend()
plt.show()
```


    
![png](output_8_0.png)
    



```python
plt.figure(figsize=(12, 6))
sns.lineplot(x='Year', y='Daily caloric intake per person that comes from animal protein', data=data, label='Calories from protein', color='blue')
sns.lineplot(x='Year', y='Mean female height (cm)', data=data, label='Female Height', color='pink')
plt.title('Trends in Male and Female Height Over the Years')
plt.xlabel('Year')
plt.legend()
plt.show()
```


    
![png](output_9_0.png)
    



```python

```
